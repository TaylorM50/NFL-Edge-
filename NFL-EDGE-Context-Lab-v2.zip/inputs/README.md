# Sourced inputs: no fabricated live data
The JSON files are intentionally empty until authoritative records are supplied. Missing is not zero and not healthy. Context page shows input counts. No secret keys belong in a public Pages repository.

## player_ids.json
Map nflverse/GSIS player ID to ESPN athlete ID. Example schema (replace placeholders, do not paste as real data):
{"GSIS_ID": "ESPN_ID"}
Names are not automatically fuzzy-matched. Incorrect identities could apply an injury to the wrong player.

## personnel.json
Array of objects:
- game_id: exact nflverse game_id
- team: normalized code (WAS, LAR, LV, LAC)
- player_id, name, position
- availability: 0..1 analyst scenario probability, or null when unresolved
- expected_snap_share: expected fraction of eligible team snaps, or null
- baseline_snap_share: same denominator/phase as expected_snap_share, or null
- replacement_drop_points: analyst estimate of team points lost if fully absent relative to baseline/replacement; may be negative if replacement is better
- source_url, as_of, expires_at: required provenance and ISO8601 UTC times

Must be game-specific. Use a source that supports the claimed workload, starting role and replacement analysis, not a generic player biography. These are analyst estimates, not ESPN-certified probability/point values. Source URLs are recorded, not automatically truth-checked. ESPN Out/IR/suspended overrides availability to zero only after an explicit player ID match. Questionable/doubtful does not imply a numerical play probability. A numerical snap cap found in an ESPN comment is flagged for human review; it is NOT silently converted to snap share without a reliable denominator. Line substitutions should have one row for the baseline player's incremental replacement loss; do not count the same loss again for the backup.

## matchups.json
Array with common game_id, team, source_url, as_of, expires_at plus:
- kind: pass_protection, route_coverage, or rusher_alignment
- description: named blockers/rushers/receivers/defenders, route or alignment and limitations
- expected_opportunities: number of relevant blocks/routes/rushes
- expected_overlap: 0..1 fraction where matchup is expected to occur
- epa_edge_per_opportunity: incremental EPA edge relative to existing team baseline (-1..1)

Example interpretation: a tackle's anticipated disadvantage against an edge rusher contributes expected opportunities × overlap × incremental EPA. A receiver versus zone is not a guaranteed one-to-one cornerback assignment. Assignments/overlap and edges require supplied charting or sourced scouting; this package does not obtain proprietary tracking. Avoid overlapping rows that double-count the same play, and do not combine a full line injury loss with the same replacement disadvantage again. Estimated forward assignments must be labeled estimates in description. These linear point effects and the log-odds conversion are unvalidated scenario sensitivities.

## venues.json
Object keyed by exact ESPN venue ID (preferred) or exact venue fullName, with:
latitude, longitude, roof (outdoor/open/closed/unknown), source_url, verified_at.
For retractable roofs set unknown until an event-specific source confirms open/closed. Review/change the record before each game; verified_at alone does not guarantee roof freshness. No home-stadium assumption: neutral and international venues require their own exact venue record. Only outdoor/open records trigger Open-Meteo. Coordinates are never inferred from a home-team code. Empty catalog means weather is unavailable, not fair conditions.
